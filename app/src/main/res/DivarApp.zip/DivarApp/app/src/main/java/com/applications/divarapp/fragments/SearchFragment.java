package com.applications.divarapp.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.applications.divarapp.R;
import com.applications.divarapp.activities.AdShowActivity;
import com.applications.divarapp.adapters.AdListAdapter;
import com.applications.divarapp.adapters.CategoryListAdapter;
import com.applications.divarapp.models.AdsModel;
import com.applications.divarapp.network.API;
import com.applications.divarapp.network.Endpoints;
import com.applications.divarapp.utils.Constants;
import com.applications.divarapp.utils.SPreferences;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchFragment extends Fragment {

    //Reference to API endpoints
    private final Endpoints endpoints = API.getRetrofitInstance().create(Endpoints.class);
    //Arguments
    private static final String ARG_CATEGORY_ID = "category_id";
    private static final String ARG_SCATEGORY_ID = "scategory_id";
    private static final String ARG_SSCATEGORY_ID = "sscategory_id";
    private static final String ARG_TEXT = "input";
    //Recycler view
    // set up the RecyclerView
    private RecyclerView recyclerViewAds ;
    //Ad adapter
    private AdListAdapter adapterAd;
    //User city id
    private int cityId;


    public static SearchFragment newInstance(int cid, int sid, int ssid, String input) {
        SearchFragment fragment = new SearchFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_CATEGORY_ID, cid);
        args.putInt(ARG_SCATEGORY_ID, sid);
        args.putInt(ARG_SSCATEGORY_ID, ssid);
        args.putString(ARG_TEXT, input);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_search, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        cityId = Integer.parseInt(SPreferences.getDefaults(Constants.Key_City_SP, getContext()).split(":")[0]);
        AssigningElements(view);
        SetListeners(view);
        GetNewAdsFilter(getArguments().getInt(ARG_SCATEGORY_ID)+"", Constants.FilterBySubCategory, "temp");
    }
    //Set listeners
    private void SetListeners(View view) {
        ((TextInputEditText)view.findViewById(R.id.txt_search_input)).addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length() == 0){
                    GetNewAdsFilter(getArguments().getInt(ARG_CATEGORY_ID)+"", Constants.FilterByCategory, "temp");
                }else{
                    GetNewAdsFilter(getArguments().getInt(ARG_CATEGORY_ID)+"", Constants.FilterByCategoryWithName, s.toString());
                }

            }
        });
    }
    private void GetNewAdsFilter(String input , int filter, String input2) {
        endpoints.FilterAds(input, filter, input2).enqueue(new Callback<ArrayList<AdsModel>>() {
            @Override
            public void onResponse(Call<ArrayList<AdsModel>> call, Response<ArrayList<AdsModel>> response) {
                if(response.body() != null){

                    recyclerViewAds.setLayoutManager(new LinearLayoutManager(getContext()));
                    adapterAd = new AdListAdapter(response.body(),getContext(),item -> {
                        Intent i = new Intent(getActivity(), AdShowActivity.class);
                        i.putExtra(Constants.Key_Extra_AId, item);
                        startActivity(i);
                    });
                    recyclerViewAds.setAdapter(adapterAd);

                }
            }

            @Override
            public void onFailure(Call<ArrayList<AdsModel>> call, Throwable t) {
                Snackbar.make(getView().findViewById(R.id.content), "مشکلی در ارتباط رخ داده است.", Snackbar.LENGTH_SHORT).show();

            }
        });


    }
    //Set elements
    private void AssigningElements(View view) {
        recyclerViewAds = view.findViewById(R.id.ads_list);
    }
}
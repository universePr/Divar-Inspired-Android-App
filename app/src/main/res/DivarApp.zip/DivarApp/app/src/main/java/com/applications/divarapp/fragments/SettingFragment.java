package com.applications.divarapp.fragments;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.applications.divarapp.R;
import com.applications.divarapp.activities.MainActivity;
import com.applications.divarapp.network.API;
import com.applications.divarapp.network.Endpoints;
import com.applications.divarapp.utils.Constants;
import com.applications.divarapp.utils.SPreferences;
import com.google.android.material.snackbar.Snackbar;

import java.util.Map;

public class SettingFragment extends Fragment {

    //Reference to API endpoints
    private final Endpoints endpoints = API.getRetrofitInstance().create(Endpoints.class);

    public static SettingFragment newInstance() {
        SettingFragment fragment = new SettingFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_setting, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        AssigningElements(view);
        SetListeners(view);
    }

    private void SetListeners(View view) {
    }

    private void AssigningElements(View view) {
        if(UserLoggedIn()){
            ((TextView)view.findViewById(R.id.txt_user)).setText("شما با شماره " +
                    SPreferences.getDefaults(Constants.Key_LoggedInUser_SP, getContext())+
                    " وارد شده اید و آگهی های ثبت شده با این شماره را مشاهده میکنید.");
            (view.findViewById(R.id.btn_logout)).setOnClickListener(v -> {
                SPreferences.logoutUser(Constants.Key_LoggedInUser_SP, getContext());
                SPreferences.logoutUser(Constants.Key_LoggedInUserToken_SP, getContext());
                SPreferences.logoutUser(Constants.Key_LoggedInUserCode_SP, getContext());

                (view.findViewById(R.id.logout_section)).setVisibility(View.GONE);
                (view.findViewById(R.id.my_ads_section)).setVisibility(View.GONE);

                Snackbar.make(getContext(), view, "با موفقیت از حساب خود خارج شدید.", Snackbar.LENGTH_SHORT).show();
            });
            (view.findViewById(R.id.my_ads_section)).setOnClickListener(v -> {
                ((MainActivity)getActivity()).ChangingFragment(MyAdFragment.newInstance(), Constants.My_Ads_Fragment_Tag);
            });
        }else{
            (view.findViewById(R.id.logout_section)).setVisibility(View.GONE);
            (view.findViewById(R.id.my_ads_section)).setVisibility(View.GONE);
        }
    }

    //Checking user logged in
    private boolean UserLoggedIn() {
        Map<String, Object> map_sp = SPreferences.hasKey(Constants.Key_LoggedInUser_SP, getContext());
        if ((boolean) map_sp.get("1")) {
            return true;
        } else {
            return false;
        }
    }
}
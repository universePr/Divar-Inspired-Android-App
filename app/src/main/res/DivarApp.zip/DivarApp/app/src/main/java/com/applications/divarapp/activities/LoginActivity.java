package com.applications.divarapp.activities;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.applications.divarapp.R;
import com.applications.divarapp.models.ResponseModel;
import com.applications.divarapp.models.SignupDataModel;
import com.applications.divarapp.network.API;
import com.applications.divarapp.network.Endpoints;
import com.applications.divarapp.utils.Constants;
import com.applications.divarapp.utils.Md5;
import com.applications.divarapp.utils.SPreferences;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    //Reference to API endpoints
    private final Endpoints endpoints = API.getRetrofitInstance().create(Endpoints.class);
    //Layout elements
    private TextInputEditText phone_number_input;
    private Button btn_send;
    private Button btn_check;
    private ImageButton btn_back;
    private TextView timer;
    private TextView msg;
    private TextView please_enter_your_number;
    //State for send sms code
    private boolean phoneIsOK = false;
    private boolean sendCodeIsOK = true;
    private boolean codeIsOK = true;
    //Getting code
    private int code;
    //Phone
    private String phone = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        AssigningElements();
        SetListeners();
    }

    private void AssigningElements() {
        //Phone input edit text
        phone_number_input = findViewById(R.id.txt_phone_input);
        //Button send
        btn_send = findViewById(R.id.btn_send);
        //Button for check code input
        btn_check = findViewById(R.id.btn_check);
        //Timer text_view
        timer = findViewById(R.id.txt_timer);
        //Message
        msg = findViewById(R.id.msg);
        //Showing user Phone input
        please_enter_your_number = findViewById(R.id.pleaseEnterYourPhone);
        //Button back : to get phone number
        btn_back = findViewById(R.id.btn_back);
    }



    public void ViewsActions(View view) {
        switch (view.getId()) {
            case R.id.btn_send:
                if(phoneIsOK && sendCodeIsOK) {
                    if(phone.equals(""))
                        phone = phone_number_input.getText().toString();
                    PostVCode();
                }
                break;
            case R.id.btn_check:
                if(phone_number_input.getText().toString().equals(""+code)){
                    PostSignup();
                }
                break;
            case R.id.btn_back:
                StartLayout();
                break;
        }
    }
    //Send post request for get code
    private void PostVCode(){
        endpoints.PostVcode(Md5.getMd5Hash(phone), phone).enqueue(new Callback<ResponseModel>() {
            @Override
            public void onResponse(Call<ResponseModel> call, Response<ResponseModel> response) {
                if(response.body() != null) {
                    Snackbar.make(findViewById(R.id.content), "کد با موفقیت ارسال شد. کد: " + response.body().getCode(), Snackbar.LENGTH_INDEFINITE).show();
                    //Save code
                    code = response.body().getCode();
                    codeIsOK = true;
                    //Layout control
                    Visible(true);
                    Invisible(true);
                    ChangeLayout();
                    //Start timer to send again request
                    sendCodeIsOK = false;
                    TimerHandler();
                }
            }

            @Override
            public void onFailure(Call<ResponseModel> call, Throwable t) {
                Snackbar.make(findViewById(R.id.content),"مشکلی در ارتباط رخ داده است.", Snackbar.LENGTH_SHORT).show();
            }
        });
    }
    //Send post request for signup user
    private void PostSignup(){
        endpoints.PostSignup(Md5.getMd5Hash(phone+code), new SignupDataModel(code, phone,UserCityId())).enqueue(new Callback<ResponseModel>() {
            @Override
            public void onResponse(Call<ResponseModel> call, Response<ResponseModel> response) {
                if(response.body() != null){
                    SPreferences.setDefaults(Constants.Key_LoggedInUser_SP, phone, LoginActivity.this);
                    SPreferences.setDefaults(Constants.Key_LoggedInUserCode_SP, ""+code, LoginActivity.this);
                    SPreferences.setDefaults(Constants.Key_LoggedInUserToken_SP, response.body().getToken(), LoginActivity.this);
                    Snackbar.make(findViewById(R.id.content),"با موفقیت وارد شدید.", Snackbar.LENGTH_SHORT).show();
                    LoginActivity.this.onBackPressed();
                }

            }

            @Override
            public void onFailure(Call<ResponseModel> call, Throwable t) {
                Snackbar.make(findViewById(R.id.content),"مشکلی در ارتباط رخ داده است.", Snackbar.LENGTH_SHORT).show();
            }
        });
    }
    //Get user city id from shared preferences
    private int UserCityId(){
        Map<String, Object> map_sp = SPreferences.hasKey(Constants.Key_City_SP, this);
        if((boolean) map_sp.get("1")){
            return Integer.parseInt(((String) (map_sp.get("2"))).split(":")[0]);
        }else {
            Intent i = new Intent(LoginActivity.this,FirstActivity.class);
            startActivity(i);
        }
        return -1;
    }
    //Set listeners
    private void SetListeners(){
        //check phone number / correct input
        phone_number_input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().matches("(\\+98|0)?9\\d{9}")) {
                    phoneIsOK = true;
                    hideKeyboard(LoginActivity.this);

                } else {
                    phoneIsOK = false;

                }
            }
        });
    }
    //Hide keyboard when user type phone number
    private void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
    // Set visibility to visible
    private void Visible(boolean visible){
        if(visible) {
            btn_check.setVisibility(View.VISIBLE);
            btn_back.setVisibility(View.VISIBLE);
            timer.setVisibility(View.VISIBLE);

        }else{
            btn_send.setVisibility(View.VISIBLE);
        }
    }
    // Set visibility to invisible
    private void Invisible(boolean invisible){
        if(invisible) {
            btn_send.setVisibility(View.INVISIBLE);
        }else{
            timer.setVisibility(View.INVISIBLE);
            btn_check.setVisibility(View.INVISIBLE);
        }
    }
    //Timer for new request to vcode
    private void TimerHandler(){
        new CountDownTimer(20000, 1000) {

            public void onTick(long millisUntilFinished) {
                timer.setText("درخواست مجدد ( ۰۰:" + millisUntilFinished / 1000 + " )");
            }

            public void onFinish() {
                phoneIsOK = true;
                sendCodeIsOK = true;
                Visible(false);
                Invisible(false);
            }

        }.start();
    }
    //Clear input phone and set new strings
    private void ChangeLayout(){
        please_enter_your_number.setText("کد تایید را وارد کنید");
        msg.setText("لطفا کد تاییدی را که به شماره " + phone + " پیامک شده وارد کنید.");
        phone_number_input.setText("");
        btn_send.setText("ارسال مجدد");
    }
    //Clear input phone and return layout to start
    private void StartLayout(){
        please_enter_your_number.setText("شماره خود را وارد کنید");
        msg.setText("برای استفاده از امکانات اپلیکیشن، لطفا شماره موبایل خود را وارد کنید. کد تایید به این شماه پیامک خواهد شد.");
        phone_number_input.setText(phone);
        btn_send.setText("بعدی");
        phone = "";
        btn_back.setVisibility(View.GONE);
        btn_check.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
package com.applications.divarapp.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.applications.divarapp.R;
import com.applications.divarapp.activities.MainActivity;
import com.applications.divarapp.adapters.CategoryAdapter;
import com.applications.divarapp.models.CategoryModel;
import com.applications.divarapp.network.API;
import com.applications.divarapp.network.Endpoints;
import com.applications.divarapp.utils.Constants;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class CategoriesFragment extends Fragment {

    //Reference to API endpoints
    private final Endpoints endpoints = API.getRetrofitInstance().create(Endpoints.class);
    //Layout elements
    private ListView lv;
    //List adapter for show items
    private CategoryAdapter adapter;

    public CategoriesFragment() {
        // Required empty public constructor
    }

    public static CategoriesFragment newInstance() {
        CategoriesFragment fragment = new CategoriesFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_categories, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        AssigningElements(view);
        GetCategories(view);
        SetListeners(view);
    }
    private void AssigningElements(View view) {
        lv = view.findViewById(R.id.categories_list);

    }
    private void SetListeners(View v){
        lv.setOnItemClickListener((parent, view, position, id) ->{
            CategoryModel model = (CategoryModel) parent.getItemAtPosition(position);
            ((MainActivity)getActivity()).ChangingFragment(SubCategoryFragment.newInstance(model.getName(),model.getIconUrl(), model.getSubs(), Constants.page_state.CATEGORIES, model.getId(),-1), Constants.SubCategory_Fragment_Tag);
        });
    }
    private void GetCategories(View view) {
        endpoints.GetCategories(Constants.Secret_Categories).enqueue(new Callback<ArrayList<CategoryModel>>() {
            @Override
            public void onResponse(Call<ArrayList<CategoryModel>> call, Response<ArrayList<CategoryModel>> response) {
                view.findViewById(R.id.progress_circular).setVisibility(View.GONE);
                if (lv.getAdapter() == null) {
                    adapter = new CategoryAdapter(getContext(), R.layout.category_list_item, response.body());
                    lv.setAdapter(adapter);

                }
            }

            @Override
            public void onFailure(Call<ArrayList<CategoryModel>> call, Throwable t) {
                Snackbar.make(view.findViewById(R.id.content), "مشکلی در ارتباط رخ داده است.", Snackbar.LENGTH_INDEFINITE)
                        .setAction("تلاش دوباره", v -> GetCategories(view)).show();
            }
        });
    }
}
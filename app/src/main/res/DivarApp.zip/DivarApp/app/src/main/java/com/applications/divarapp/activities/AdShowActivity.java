package com.applications.divarapp.activities;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import com.applications.divarapp.R;
import com.applications.divarapp.adapters.ImageAdapter;
import com.applications.divarapp.fragments.ReportFragment;
import com.applications.divarapp.models.AdsModel;
import com.applications.divarapp.utils.Constants;
import com.google.android.material.bottomsheet.BottomSheetDialog;

public class AdShowActivity extends AppCompatActivity {

    //Data model
    private AdsModel model;
    //Fragment transaction
    private FragmentTransaction fragmentTransaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_ad);
        Intent i = getIntent();
        model = (AdsModel) i.getSerializableExtra(Constants.Key_Extra_AId);
        AssigningElements();
        SetListeners();
    }

    private void SetListeners() {
        //Buttons
        if(model.isCanMessage()) {
            findViewById(R.id.btn_chat).setOnClickListener(v ->{

            });
        }else{
            findViewById(R.id.btn_chat).setVisibility(View.INVISIBLE);
        }
        if(model.isShowPhon()){
            findViewById(R.id.btn_show_phone).setOnClickListener(v -> {
                showBottomSheetDialog();
            });
        }else{
            findViewById(R.id.btn_show_phone).setVisibility(View.INVISIBLE);
        }
        findViewById(R.id.btn_back).setOnClickListener(v -> {
            onBackPressed();
        });
        findViewById(R.id.btn_menu).setOnClickListener(v -> {

        });
        findViewById(R.id.btn_bookmark).setOnClickListener(v -> {

        });


        //Layouts
        findViewById(R.id.about_section).setOnClickListener(v -> {

        });
        findViewById(R.id.report_section).setOnClickListener(v -> {
            findViewById(R.id.content).setVisibility(View.GONE);
            ChangingFragment(ReportFragment.newInstance(model.getAdId()), Constants.Report_Fragment_Tag);
        });
    }
    //For transaction current fragment to input
    private void TransactionFragment(Fragment fragment, String Tag){
        fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.page_frame,fragment, Tag);
        fragmentTransaction.addToBackStack(Tag);
        fragmentTransaction.commit();
    }
    //This calling by fragment
    public void ChangingFragment(Fragment fragment, String Tag){
        TransactionFragment(fragment, Tag);
    }
    private void AssigningElements() {
        if(model.isContainImage()) {
            ViewPager mViewPager = (ViewPager) findViewById(R.id.viewPage);
            ImageAdapter adapterView = new ImageAdapter(getBaseContext(), model.getImageUrls());
            mViewPager.setAdapter(adapterView);
            ((TextView)findViewById(R.id.img_numebr)).setText(model.getImageUrls().size() + " تصویر");
        }
        ((TextView)findViewById(R.id.ad_title)).setText(model.getTitle());
        ((TextView)findViewById(R.id.ad_desc)).setText(model.getDescription());
        ((TextView)findViewById(R.id.txt_cat)).setText(model.getCategoryName());
        ((TextView)findViewById(R.id.txt_price)).setText(model.getFinalPrice() + " تومان");
        ((TextView)findViewById(R.id.txt_status)).setText(model.isStatus()? "فوری" : "عادی");
        ((TextView)findViewById(R.id.txt_desc)).setText(model.getDescription());
    }
    private void showBottomSheetDialog() {

        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_dialog_layout);

        LinearLayout call = bottomSheetDialog.findViewById(R.id.call);
        LinearLayout msg = bottomSheetDialog.findViewById(R.id.msg);
        ((TextView)call.findViewById(R.id.txt_call)).setText(
                "تماس تلفنی با " + model.getPhone()
        );
        ((TextView)msg.findViewById(R.id.txt_msg)).setText(
                "ارسال پیامک به " + model.getPhone()
        );
        call.setOnClickListener(v -> {
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:"+model.getPhone()));
            startActivity(callIntent);
        });
        msg.setOnClickListener(v -> {
            Intent smsIntent = new Intent(Intent.ACTION_VIEW);
            smsIntent.setData(Uri.parse("sms:"+model.getPhone()));
            startActivity(smsIntent);
        });

        bottomSheetDialog.show();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        findViewById(R.id.content).setVisibility(View.VISIBLE);
    }
}
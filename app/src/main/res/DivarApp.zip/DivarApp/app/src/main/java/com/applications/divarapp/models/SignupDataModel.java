package com.applications.divarapp.models;

import com.google.gson.annotations.SerializedName;

public class SignupDataModel {
    @SerializedName("cd")
    private int Code;
    @SerializedName("ph")
    private String Phone;
    @SerializedName("ci")
    private int CityId;

    public SignupDataModel(int code, String phone, int cityId) {
        Code = code;
        Phone = phone;
        CityId = cityId;
    }
}

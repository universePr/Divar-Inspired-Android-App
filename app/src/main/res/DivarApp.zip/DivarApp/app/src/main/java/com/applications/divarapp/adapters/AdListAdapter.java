package com.applications.divarapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.applications.divarapp.R;
import com.applications.divarapp.models.AdsModel;
import com.applications.divarapp.models.CategoryModel;
import com.applications.divarapp.network.API;
import com.bumptech.glide.Glide;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;

public class AdListAdapter extends RecyclerView.Adapter<AdListAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(AdsModel item);
    }

    private ArrayList<AdsModel> adsItems = new ArrayList<>();
    private LayoutInflater mInflater;
    private Context context;
    //Click listener
    private final AdListAdapter.OnItemClickListener listener;

    // data is passed into the constructor
    public AdListAdapter(ArrayList<AdsModel> adsItems, Context context, AdListAdapter.OnItemClickListener listener) {
        this.adsItems = adsItems;
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
        this.listener = listener;
    }

    // inflates the row layout from xml when needed
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.ad_item_layout, parent, false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AdsModel ad = adsItems.get(position);
        holder.ad_title.setText(ad.getTitle());
        if(ad.getFinalPrice() != 0) {
            holder.ad_price.setText("قیمت: " + (int)ad.getFinalPrice() + " تومان");
        }
        DateTimeFormatter formatter = null;



        holder.ad_time.setText("تاریخ:" + ad.getDateTime().split(" ")[0].toString() + " در " + ad.getCityName());



        if(ad.isContainImage()){
            Glide.with(context)
                    .load(API.getBaseUrlApi() + ad.getImageUrls().get(0))
                    .fitCenter()
                    .into(holder.img);
        }
        if(!ad.isCanMessage()){
            holder.chat_img.setVisibility(View.INVISIBLE);
        }
        holder.bind(ad, listener);

    }

    @Override
    public int getItemCount() {
        return adsItems.size();
    }

    // stores and recycles views as they are scrolled off screen
    public class ViewHolder extends RecyclerView.ViewHolder {
        //Text views
        TextView ad_title;
        TextView ad_price;
        TextView ad_time;
        //Image views
        ImageView img;
        ImageView chat_img;

        public ViewHolder(View itemView) {
            super(itemView);
            ad_title = itemView.findViewById(R.id.ad_title);
            ad_price = itemView.findViewById(R.id.ad_price);
            ad_time = itemView.findViewById(R.id.ad_time);
            //Image view
            img = itemView.findViewById(R.id.img);
            chat_img = itemView.findViewById(R.id.chat_img);
        }
        public void bind(AdsModel item, final AdListAdapter.OnItemClickListener listener) {
            itemView.setOnClickListener(v -> {
                listener.onItemClick(item);
            });
        }
    }
}
